// $result = "";

        // $jenis = isset($jenis) ? $jenis : 'kosong';

        // $jenis = !empty($jenis) ? $jenis : 'kosong';


        // if($jenis == null)
        // {
        //     $result = "eee";
        // }
        // else
        // {
        //     $result = DB::table('jenis_barang')->select('*')->where('jenis_barang', 'like', '%'.$jenis.'%')->get();
        // }
        // return response()->json(['jenis'=>'$request->jenis']);