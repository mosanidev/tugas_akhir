<?php

namespace App\Http\Controllers\Pelanggan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class ShopController extends Controller
{
    public function index()
    {
        $data_jenis = DB::table('jenis_barang')->get();
        $data_barang = DB::table('barang')->select('*')->where('jumlah_stok', '>', 0)->limit(5)->get();

        if (Auth::check())
        {
            $total_cart = DB::table('cart')->select(DB::raw('count(*) as total_cart'))->where('cart.users_id', '=', auth()->user()->id)->get();
        }

        return view('pelanggan.shop.shop_by_jenis', ['jenis_barang' => $data_jenis, 'barang' => $data_barang, 'total_cart'=>$total_cart]);
    }

    
}
