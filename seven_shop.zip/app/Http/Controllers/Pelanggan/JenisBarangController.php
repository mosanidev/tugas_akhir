<?php

namespace App\Http\Controllers\Pelanggan;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class JenisBarangController extends Controller
{
    // public function show()
    // {
    //     $data_jenis = DB::table('jenis_barang')->get();
    //     return view('pelanggan.shop', ['state' => 'jenis', 'jenis_barang' => $data_jenis]);
    // }
}
